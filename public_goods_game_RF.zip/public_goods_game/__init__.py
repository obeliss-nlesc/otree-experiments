from otree.api import *

class Constants(BaseConstants):
    """
    This class defines the constants used in the game.
    """
    name_in_url = "public_goods_punishment"
    title = "test experiment"
    # all players should be in the same group; num_participants will be inherited from the session config.
    players_per_group = None
    num_rounds = 3
    num_recent_rounds_to_display = 3
    endowment = 20
    min_payout = 5
    efficiency_factor = 0.375
    real_world_currency_per_point = 0.01
    punishment_costs = [0, 1, 2, 4, 6, 9, 12, 16, 20, 25, 30]
    min_players_per_group = 3
    introduction_timeout_seconds = 900  # 15 minutes
    other_pages_timeout_seconds = 30  # 2 minutes
    return_from_timeout_seconds = 10

class Subsession(BaseSubsession):
    """
    This class represents a subsession of the game.
    """
    pass

def creating_session(subsession):
    """
    This function is called when creating a new session.
    It sets the 'is_dropout' attribute of each participant to False.
    """
    if subsession.round_number == 1:
        players = subsession.get_players()
        num_players = len(players)

        # Debugging
        print(f"Number of players: {num_players}")
        print(f"Punishment: {subsession.session.config.get('punishment_condition')}")

        # Set 'is_dropout' to False for each player
        for player in players:
            player.participant.is_dropout = False

class Group(BaseGroup):
    total_group_investment = models.CurrencyField(initial=0)
    punishment_condition = models.BooleanField()
    number_of_inactive = models.IntegerField(initial=0)
    inactive_players = models.IntegerField(initial=0)
    failed = models.BooleanField(initial=False)

    def set_first_stage_earnings(self):
        """
        This function calculates the first stage earnings for each player in the group.
        It calculates the total group investment and assigns the payoff from private and public accounts to each player.
        """
        players = self.get_players()
        self.total_group_investment = sum([p.public_investment for p in players])
        for p in players:
            p.payoff_from_private = p.endowment - p.public_investment
            p.payoff_from_public = Constants.efficiency_factor * self.total_group_investment
            p.gross_profit = p.payoff_from_private + p.payoff_from_public
            print(f"Gross profit for Player {p.id_in_group}: {p.gross_profit} points.")

class Player(BasePlayer):
    # Existing investment field
    payoff_from_private = models.CurrencyField()
    payoff_from_public = models.CurrencyField()
    endowment = models.CurrencyField(initial=Constants.endowment)
    gross_profit = models.CurrencyField(initial=0)

    public_investment = models.CurrencyField(
        min=0,
        max=Constants.endowment,
        initial=0,
        verbose_name="Hoe veel wil je investeren in de publieke rekening?",
        widget=widgets.RadioSelect,
        choices=[i for i in range(0, Constants.endowment + 1)],
    )

    received_punishment = models.CurrencyField(initial=0)
    total_punishment_cost = models.CurrencyField(initial=0)

    def set_punishment_and_final_payoffs(self):
        """
        This function calculates the final payoffs for the player (self).
        It retrieves all punishment points received, computes the total cost of giving punishments,
        calculates the proportion of punishment reduction, and determines the final earnings.

        @RF: this is a different function than Tilia's, but now the punishment mechanism works properly
        print statements for debugging purposes
        """
        print(f"Player {self.id_in_group}:")
        print(f"Player {self.id_in_group} - Gross Profit: {self.gross_profit}")
        # Retrieve total punishment points received from other players
        self.received_punishment = sum(
            getattr(other_player, f"punishment_sent_to_player_{self.id_in_group}", 0)
            for other_player in self.get_others_in_group()
        )
        print(f"Player {self.id_in_group} - Received Punishment: {self.received_punishment}")
        # Calculate the total cost incurred for giving punishment
        for other_player in self.get_others_in_group():
            punishment_points = getattr(self, f"punishment_sent_to_player_{other_player.id_in_group}")
            self.total_punishment_cost += Constants.punishment_costs[int(punishment_points)]
        print(f"Player {self.id_in_group} - Total Punishment Cost: {self.total_punishment_cost}")
        # Calculate the proportion of gross profit reduction
        punishment_reduction_proportion = min(1, int(str(self.received_punishment).split()[0]) / 10)
        print(f"Player {self.id_in_group} - Gross Profit Reduction Proportion: {punishment_reduction_proportion}")
        # Final earnings after applying reduction and substracting costs
        final_earnings = self.gross_profit * (1 - punishment_reduction_proportion)
        print(f"Player {self.id_in_group} - Income after reduction of punishment received: {final_earnings}")
        final_earnings = final_earnings - self.total_punishment_cost
        print(f"Player {self.id_in_group} - Income after reduction of incurred punishment costs: {final_earnings}")
        # Ensure the final earnings are non-negative
        self.payoff = max(0, final_earnings)

# Setting punishment_fields in the Player class. Used to dynamically generate number of forms on the PunishmentPage.
#@RF: not the most sophisticated solution, but just generate 30 fields; in the small group conditions,
# naturally, others than the first 3 are 'structural zero'.

max_group_size = 30

for i in range(1, max_group_size + 1):
    setattr(
        Player,
        f"punishment_sent_to_player_{i}",
        models.CurrencyField(
            initial=0,
            verbose_name=f"Kies een straf voor speler #{i}:",
            widget=widgets.RadioSelect,
            choices=[0, 5, 10],
        ),
    )

def timeout_check(player, timeout_happened):

    """
    This function checks if a timeout has occurred for a player.
    If a timeout has occurred and the participant is not a dropout, it marks the player as inactive and sets the participant as a dropout.
    If the number of inactive players reaches the minimum required number, it marks the group as failed.
    """
    participant = player.participant
    groupsize = len(player.get_others_in_group()) + 1

    if timeout_happened and not participant.is_dropout:
        player.group.inactive_players += 1
        participant.is_dropout = True
        print(f"{participant} has dropped out of the group.")
        print(f"Number of inactive players in the group: {player.group.inactive_players}")

    if player.group.inactive_players > groupsize - Constants.min_players_per_group:
        player.group.failed = True
        print(f"Group failed due to too many inactive players.")

def timeout_time(player, timeout_seconds):
    """
    This function calculates the timeout time for a player.
    If the participant is a dropout or the group has failed, it returns an instant timeout of 1 second.
    Otherwise, it returns the specified timeout_seconds.

    Args:
        player (Player): The player for whom to calculate the timeout time.
        timeout_seconds (int): The timeout duration in seconds.

    Returns:
        int: The calculated timeout time in seconds.
    """
    participant = player.participant

    if participant.is_dropout or player.group.failed:
        return 1  # instant timeout, 1 second
    else:
        return timeout_seconds


class IntroductionPage(Page):
    """
    This class represents the introduction page of the game.
    """

    def vars_for_template(player):
        """
        This function provides the template variables for the introduction page.
        It returns the punishment condition from the session configuration.

        Args:
            player (Player): The player for whom to provide the template variables.

        Returns:
            dict: The template variables.
        """
        return dict(
            punishment_condition=player.session.config.get("punishment_condition"),
            groupsize = player.session.config.get("num_demo_participants")
        )

    def is_displayed(player):
        """
        This function determines whether the introduction page should be displayed.
        It returns True if it is the first round, False otherwise.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the page should be displayed, False otherwise.
        """
        # Show this page only on the first round
        return player.round_number == 1

    def get_timeout_seconds(player):
        """
        This function calculates the timeout time for the introduction page.
        If the participant is a dropout or the group has failed, it returns an instant timeout of 1 second.
        Otherwise, it returns the specified introduction timeout seconds.

        Args:
            player (Player): The player for whom to calculate the timeout time.

        Returns:
            int: The calculated timeout time in seconds.
        """
        return timeout_time(player, Constants.introduction_timeout_seconds)

    def before_next_page(player, timeout_happened):
        """
        This function is called before moving to the next page.
        It checks if a timeout has occurred and updates the player's status accordingly.

        Args:
            player (Player): The player for whom to perform the before_next_page actions.
            timeout_happened (bool): True if a timeout has occurred, False otherwise.
        """
        timeout_check(player, timeout_happened)


class Contribution(Page):
    """
    This class represents the contribution page of the game.
    """

    form_model = "player"
    form_fields = ["public_investment"]

    def vars_for_template(player):
        """
        This function provides the template variables for the contribution page.
        It returns the round number and the endowment from the Constants class.

        Args:
            player (Player): The player for whom to provide the template variables.

        Returns:
            dict: The template variables.
        """
        return dict(
            round_number=player.round_number,
            endowment=Constants.endowment,
        )

    def error_message(player, values):
        """
        This function checks if there is an error in the submitted form values.
        It returns an error message if the sum of the investments exceeds the endowment.

        Args:
            player (Player): The player for whom to check the form values.
            values (dict): The submitted form values.

        Returns:
            str: The error message, or None if there is no error.
        """
        if sum(values.values()) > Constants.endowment:
            return "The sum of your investments cannot exceed your endowment."

    def get_timeout_seconds(player):
        """
        This function calculates the timeout time for the contribution page.
        If the participant is a dropout or the group has failed, it returns an instant timeout of 1 second.
        Otherwise, it returns the specified other pages timeout seconds.

        Args:
            player (Player): The player for whom to calculate the timeout time.

        Returns:
            int: The calculated timeout time in seconds.
        """
        return timeout_time(player, Constants.other_pages_timeout_seconds)

    def before_next_page(player, timeout_happened):
        """
        This function is called before moving to the next page.
        It checks if a timeout has occurred and updates the player's status accordingly.

        Args:
            player (Player): The player for whom to perform the before_next_page actions.
            timeout_happened (bool): True if a timeout has occurred, False otherwise.
        """
        timeout_check(player, timeout_happened)

    def is_displayed(player):
        """
        This function determines whether the contribution page should be displayed.
        It returns True if the group has not failed and the participant is not a dropout, False otherwise.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the page should be displayed, False otherwise.
        """
        return not player.group.failed and not player.participant.is_dropout


class GroupWaitPage(WaitPage):

    def after_all_players_arrive(group):
        """
        This function is called after all players in the group have arrived.
        It sets the first stage earnings for the group.

        Args:
            group (Group): The group for which to set the first stage earnings.
        """
        group.set_first_stage_earnings()


    def is_displayed(player):
        """
        This function determines whether the group wait page should be displayed.
        It returns True if the group has not failed and the participant is not a dropout, False otherwise.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the page should be displayed, False otherwise.
        """
        return not player.group.failed and not player.participant.is_dropout

class FirstStageResults(Page):
    """
    This class represents the first stage results page of the game.
    """

    def vars_for_template(player):
        """
        This function provides the template variables for the first stage results page.

        Args:
            player (Player): The player for whom to provide the template variables.

        Returns:
            dict: The template variables.
        """
        return dict(
            round_number=player.round_number,
        )

    def get_timeout_seconds(player):
        """
        This function calculates the timeout time for the first stage results page.
        If the participant is a dropout or the group has failed, it returns an instant timeout of 1 second.
        Otherwise, it returns the specified other pages timeout seconds.

        Args:
            player (Player): The player for whom to calculate the timeout time.

        Returns:
            int: The calculated timeout time in seconds.
        """
        return timeout_time(player, Constants.other_pages_timeout_seconds)

    def before_next_page(player, timeout_happened):
        """
        This function is called before moving to the next page.
        It checks if a timeout has occurred and updates the player's status accordingly.

        Args:
            player (Player): The player for whom to perform the before_next_page actions.
            timeout_happened (bool): True if a timeout has occurred, False otherwise.
        """
        timeout_check(player, timeout_happened)

    def is_displayed(player):
        """
        This function determines whether the first stage results page should be displayed.
        It returns True if the group has not failed and the participant is not a dropout, False otherwise.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the page should be displayed, False otherwise.
        """
        return not player.group.failed and not player.participant.is_dropout


class ObservationPage(Page):
    """
    This class represents the observation page of the game.
    """

    def vars_for_template(player):
        """
        This function provides the variables needed for rendering the template of the observation page.

        Args:
            player (Player): The player for whom to provide the variables.

        Returns:
            dict: A dictionary containing the variables needed for rendering the template.
        """
        players_in_all_rounds = [players.in_all_rounds() for players in player.group.get_players()]
        current_round = player.round_number

        # Compute the first round to display (cannot be less than 1)
        first_round_to_display = max(1, current_round - Constants.num_recent_rounds_to_display + 1)
        # Construct the data structure for the table
        table_data = []
        for round_number in range(first_round_to_display, current_round + 1):
            round_data = []
            for players in players_in_all_rounds:
                public_investment = players[round_number - 1].public_investment
                private_investment = players[round_number - 1].payoff_from_private
                payoff = players[round_number - 1].gross_profit
                round_data.append([public_investment, private_investment, payoff])
            table_data.append((round_number, round_data))

        return dict(
            round_number=current_round,
            table_data=table_data,
            player_id=player.id_in_group,
        )

    def is_displayed(player):
        """
        This function determines whether the observation page should be displayed.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the page should be displayed, False otherwise.
        """
        return (
            not player.session.config.get("punishment_condition")
            and not player.group.failed
            and not player.participant.is_dropout
        )

    def get_timeout_seconds(player):
        """
        This function calculates the timeout time for the observation page.

        Args:
            player (Player): The player for whom to calculate the timeout time.

        Returns:
            int: The calculated timeout time in seconds.
        """
        return timeout_time(player, Constants.other_pages_timeout_seconds)

    def before_next_page(player, timeout_happened):
        """
        This function is called before moving to the next page.
        It checks if a timeout has occurred and updates the player's status accordingly.

        Args:
            player (Player): The player for whom to perform the before_next_page actions.
            timeout_happened (bool): True if a timeout has occurred, False otherwise.
        """
        timeout_check(player, timeout_happened)


class PunishmentPage(Page):
    """
    This class represents the punishment page of the game.
    """

    form_model = "player"

    def get_form_fields(player):
        """
        This function returns the form fields for the punishment page.
        It dynamically generates the form fields based on the number of other players in the group.

        Args:
            player (Player): The player for whom to generate the form fields.

        Returns:
            list: The list of form fields for the punishment page.
        """
        other_players = [f"punishment_sent_to_player_{i.id_in_group}" for i in player.get_others_in_group()]

        return other_players

    def vars_for_template(player):
        """
        This function returns the variables for the punishment page template.
        It computes the data structure for the table displaying previous rounds' data.

        Args:
            player (Player): The player for whom to compute the variables.

        Returns:
            dict: The variables for the punishment page template.
        """
        players_in_all_rounds = [player.in_all_rounds() for player in player.group.get_players()]
        current_round = player.round_number

        # Compute the first round to display (cannot be less than 1)
        first_round_to_display = max(1, current_round - Constants.num_recent_rounds_to_display + 1)
        # Construct the data structure for the table
        table_data = []
        for round_number in range(first_round_to_display, current_round + 1):
            round_data = []
            for players in players_in_all_rounds:
                public_investment = players[round_number - 1].public_investment
                private_investment = players[round_number - 1].payoff_from_private
                payoff = players[round_number - 1].gross_profit
                round_data.append([public_investment, private_investment, payoff])
            table_data.append((round_number, round_data))
        other_players = [f"punishment_sent_to_player_{i.id_in_group}" for i in player.get_others_in_group()]
        return dict(
            round_number=current_round,
            table_data=table_data,
            player_id=player.id_in_group,
            players=other_players,
            punishment_costs=Constants.punishment_costs,
        )

    def is_displayed(player):
        """
        This function determines whether the punishment page should be displayed for a player.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the punishment page should be displayed, False otherwise.
        """
        return (
            player.session.config.get("punishment_condition")
            and not player.group.failed
            and not player.participant.is_dropout
        )

    def error_message(player, values):
        """
        This function returns an error message if the total punishment cost exceeds the player's earnings.

        Args:
            player (Player): The player for whom to check the punishment cost.
            values (dict): The values of the punishment form fields.

        Returns:
            str: The error message if the punishment cost exceeds the earnings, None otherwise.
        """
        cost = sum([Constants.punishment_costs[int(value)] for value in values.values()])

        if cost > player.gross_profit:
            return "De totale kosten voor het geven van strafpunten kunnen niet hoger zijn dan je opgebouwde winst."

    def get_timeout_seconds(player):
        """
        This function calculates the timeout time for the punishment page.

        Args:
            player (Player): The player for whom to calculate the timeout time.

        Returns:
            int: The calculated timeout time in seconds.
        """
        return timeout_time(player, Constants.other_pages_timeout_seconds)

    def before_next_page(player, timeout_happened):
        """
        This function is called before moving to the next page.
        It checks if a timeout has occurred and updates the player's status accordingly.

        Args:
            player (Player): The player for whom to perform the before_next_page actions.
            timeout_happened (bool): True if a timeout has occurred, False otherwise.
        """
        timeout_check(player, timeout_happened)


class PunishmentWaitPage(WaitPage):
    def after_all_players_arrive(group):
        """
        This function is called after all players in the group have arrived.
        It sets the punishment and final payoffs for each player in the group.
        """
        for player in group.get_players():
            player.set_punishment_and_final_payoffs()

    def is_displayed(player):
        """
        This function determines whether the punishment wait page should be displayed for a player.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the punishment wait page should be displayed, False otherwise.
        """
        return (
            player.session.config.get("punishment_condition")
            and not player.group.failed
            and not player.participant.is_dropout
        )


class FinalRoundResults(Page):
    """
    This class represents the final round results page of the game.
    """

    def is_displayed(player):
        """
        Determines whether the final round results page should be displayed for a player.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the final round results page should be displayed, False otherwise.
        """
        return (
            player.session.config.get("punishment_condition")
            and not player.group.failed
            and not player.participant.is_dropout
        )

    def vars_for_template(player):
        """
        Provides the variables for the template of the final round results page.

        Args:
            player (Player): The player for whom to provide the variables.

        Returns:
            dict: The variables for the template.
        """
        # Calculating the accumulated payoff
        accumulated_payoff = sum(players.payoff for players in player.in_all_rounds())
        return dict(
            punishment_reduction_percentage=min(1, int(player.received_punishment) / 10) * 100,
            round_number=player.round_number,
            accumulated_payoff=accumulated_payoff,
        )

    def get_timeout_seconds(player):
        """
        Calculates the timeout time for the final round results page.

        Args:
            player (Player): The player for whom to calculate the timeout time.

        Returns:
            int: The calculated timeout time in seconds.
        """
        return timeout_time(player, Constants.other_pages_timeout_seconds)

    def before_next_page(player, timeout_happened):
        """
        Performs actions before moving to the next page.

        Args:
            player (Player): The player for whom to perform the before_next_page actions.
            timeout_happened (bool): True if a timeout has occurred, False otherwise.
        """
        timeout_check(player, timeout_happened)


class FinalGameResults(Page):
    """
    This class represents the final game results page of the game.
    """

    def is_displayed(player):
        """
        Determines whether the final game results page should be displayed for a player.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the final game results page should be displayed, False otherwise.
        """
        return (
            player.round_number == Constants.num_rounds
            and not player.group.failed
            and not player.participant.is_dropout
        )

    def vars_for_template(player):
        """
        Provides the variables for the template of the final game results page.

        Args:
            player (Player): The player for whom to provide the variables.

        Returns:
            dict: The variables for the template.
        """
        player_accumulated_payoff = sum(
            (players.payoff if player.session.config.get("punishment_condition") else players.gross_profit)
            for players in player.in_all_rounds()
        )
        return dict(player_accumulated_payoff=player_accumulated_payoff)


class TimeoutPlayerPage(Page):
    """
    This class represents the timeout player page of the game.
    """

    def is_displayed(player):
        """
        Determines whether the timeout player page should be displayed for a player.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the timeout player page should be displayed, False otherwise.
        """
        return player.participant.is_dropout and not player.group.failed

    def before_next_page(player, timeout_happened):
        """
        Performs actions before moving to the next page.

        Args:
            player (Player): The player for whom to perform the before_next_page actions.
            timeout_happened (bool): True if a timeout has occurred, False otherwise.
        """
        if not timeout_happened:
            player.participant.is_dropout = False

    def get_timeout_seconds(player):
        """
        Calculates the timeout time for the timeout player page.

        Args:
            player (Player): The player for whom to calculate the timeout time.

        Returns:
            int: The calculated timeout time in seconds.
        """
        return Constants.return_from_timeout_seconds


class FailedGamePage(Page):
    """
    This class represents the failed game page of the game.
    """

    def vars_for_template(player):
        """
        Provides the variables for the template of the failed game page.

        Args:
            player (Player): The player for whom to provide the variables.

        Returns:
            dict: The variables for the template.
        """
        return dict(one_dropout=player.participant.is_dropout and player.round_number == Constants.num_rounds)

    def is_displayed(player):
        """
        Determines whether the failed game page should be displayed for a player.

        Args:
            player (Player): The player for whom to determine the display status.

        Returns:
            bool: True if the failed game page should be displayed, False otherwise.
        """
        return player.group.failed or (player.participant.is_dropout and player.round_number == Constants.num_rounds)


# Page sequence
page_sequence = [
    IntroductionPage,
    Contribution,
    GroupWaitPage,
    FirstStageResults,
    ObservationPage,
    PunishmentPage,
    PunishmentWaitPage,
    FinalRoundResults,
    FinalGameResults,
    TimeoutPlayerPage,
    FailedGamePage,
]
